#include <rclcpp/rclcpp.hpp>
#include <postech_flipper_msgs/msg/flipper_velocity_command.hpp>
#include <postech_flipper_msgs/msg/flipper_direction_command.hpp>
#include <memory>

// =======================
// 방향 상태 정의
// =======================
enum class DirectionSign
{
    STOP = 0,
    POSITIVE,
    NEGATIVE
};

static const char* dir_to_str(bool up, bool down)
{
    if (up)   return "UP";
    if (down) return "DOWN";
    return "STOP";
}

class FlipperVelocityToDirection : public rclcpp::Node
{
public:
    FlipperVelocityToDirection()
        : Node("flipper_velocity_to_direction")
    {
        velocity_threshold_ =
            this->declare_parameter<double>("velocity_threshold", 0.3);

        velocity_sub_ =
            this->create_subscription<postech_flipper_msgs::msg::FlipperVelocityCommand>(
                "/postech/flipper_velocity_command", 10,
                std::bind(&FlipperVelocityToDirection::velocity_callback,
                          this, std::placeholders::_1));

        direction_pub_ =
            this->create_publisher<postech_flipper_msgs::msg::FlipperDirectionCommand>(
                "/postech/flipper_direction_command", 10);

        RCLCPP_INFO(this->get_logger(), "==========================================");
        RCLCPP_INFO(this->get_logger(), " Flipper Velocity → Direction Node Started ");
        RCLCPP_INFO(this->get_logger(), " [SUB] /postech/flipper_velocity_command");
        RCLCPP_INFO(this->get_logger(), " [PUB] /postech/flipper_direction_command");
        RCLCPP_INFO(this->get_logger(), "==========================================");
    }

private:
    DirectionSign velocity_to_sign(double velocity)
    {
        if (velocity > velocity_threshold_)
            return DirectionSign::POSITIVE;
        else if (velocity < -velocity_threshold_)
            return DirectionSign::NEGATIVE;
        else
            return DirectionSign::STOP;
    }

    bool convert_with_safe_stop(
        double velocity,
        DirectionSign& prev_sign,
        bool& up,
        bool& down)
    {
        DirectionSign curr_sign = velocity_to_sign(velocity);

        bool sign_flip =
            (prev_sign == DirectionSign::POSITIVE && curr_sign == DirectionSign::NEGATIVE) ||
            (prev_sign == DirectionSign::NEGATIVE && curr_sign == DirectionSign::POSITIVE);

        if (sign_flip)
        {
            up = false;
            down = false;
            prev_sign = DirectionSign::STOP;
            return true; // STOP 강제 발생
        }

        if (curr_sign == DirectionSign::POSITIVE)
        {
            up = true;
            down = false;
        }
        else if (curr_sign == DirectionSign::NEGATIVE)
        {
            up = false;
            down = true;
        }
        else
        {
            up = false;
            down = false;
        }

        prev_sign = curr_sign;
        return false;
    }

    void velocity_callback(
        const postech_flipper_msgs::msg::FlipperVelocityCommand::SharedPtr msg)
    {
        RCLCPP_INFO(this->get_logger(),
            "\n[RECV] /postech/flipper_velocity_command\n"
            "       FL=%+.2f FR=%+.2f RL=%+.2f RR=%+.2f",
            msg->fl_velocity, msg->fr_velocity,
            msg->rl_velocity, msg->rr_velocity);

        postech_flipper_msgs::msg::FlipperDirectionCommand direction_msg;

        bool forced_stop = false;

        forced_stop |= convert_with_safe_stop(msg->fl_velocity, prev_fl_,
                                              direction_msg.fl_up, direction_msg.fl_down);
        forced_stop |= convert_with_safe_stop(msg->fr_velocity, prev_fr_,
                                              direction_msg.fr_up, direction_msg.fr_down);
        forced_stop |= convert_with_safe_stop(msg->rl_velocity, prev_rl_,
                                              direction_msg.rl_up, direction_msg.rl_down);
        forced_stop |= convert_with_safe_stop(msg->rr_velocity, prev_rr_,
                                              direction_msg.rr_up, direction_msg.rr_down);

        if (forced_stop)
        {
            RCLCPP_WARN(this->get_logger(),
                        "[SAFE] Direction flip detected → FORCE STOP");
        }

        direction_pub_->publish(direction_msg);

        RCLCPP_INFO(this->get_logger(),
            "[SEND] /postech/flipper_direction_command\n"
            "       FL=%s FR=%s RL=%s RR=%s",
            dir_to_str(direction_msg.fl_up, direction_msg.fl_down),
            dir_to_str(direction_msg.fr_up, direction_msg.fr_down),
            dir_to_str(direction_msg.rl_up, direction_msg.rl_down),
            dir_to_str(direction_msg.rr_up, direction_msg.rr_down));
    }

    // =======================
    // 멤버 변수
    // =======================
    rclcpp::Subscription<postech_flipper_msgs::msg::FlipperVelocityCommand>::SharedPtr velocity_sub_;
    rclcpp::Publisher<postech_flipper_msgs::msg::FlipperDirectionCommand>::SharedPtr direction_pub_;

    double velocity_threshold_;

    DirectionSign prev_fl_ = DirectionSign::STOP;
    DirectionSign prev_fr_ = DirectionSign::STOP;
    DirectionSign prev_rl_ = DirectionSign::STOP;
    DirectionSign prev_rr_ = DirectionSign::STOP;
};

int main(int argc, char * argv[])
{
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<FlipperVelocityToDirection>());
    rclcpp::shutdown();
    return 0;
}
