#!/usr/bin/env python3

"""
Launch file to run flipper attitude control + velocity→direction converter

Exposed parameters:
- velocity_threshold: rad/s below which velocity is treated as 0 (default: 0.05)
- Kp_omega, tau_rho, rho_dot_max_deg, w_task, w_rho, w_damp_base: flipper_attitude_control gains
"""

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    # Common parameters as launch arguments
    velocity_threshold_arg = DeclareLaunchArgument(
        'velocity_threshold',
        default_value='0.05',
        description='Velocity magnitude below which flipper is considered STOP [rad/s]',
    )

    Kp_omega_arg = DeclareLaunchArgument(
        'Kp_omega',
        default_value='3.0',
        description='Attitude error → angular velocity gain',
    )
    tau_rho_arg = DeclareLaunchArgument(
        'tau_rho',
        default_value='1.0',
        description='Time constant for rho convergence [s]',
    )
    rho_dot_max_deg_arg = DeclareLaunchArgument(
        'rho_dot_max_deg',
        default_value='30.0',
        description='Max flipper speed [deg/s]',
    )
    w_task_arg = DeclareLaunchArgument(
        'w_task',
        default_value='2.0',
        description='Task (attitude) weight',
    )
    w_rho_arg = DeclareLaunchArgument(
        'w_rho',
        default_value='5e-4',
        description='Weight driving rho towards 0',
    )
    w_damp_base_arg = DeclareLaunchArgument(
        'w_damp_base',
        default_value='5e-5',
        description='Base damping weight (scaled by condition number)',
    )

    # Launch configurations
    velocity_threshold = LaunchConfiguration('velocity_threshold')
    Kp_omega = LaunchConfiguration('Kp_omega')
    tau_rho = LaunchConfiguration('tau_rho')
    rho_dot_max_deg = LaunchConfiguration('rho_dot_max_deg')
    w_task = LaunchConfiguration('w_task')
    w_rho = LaunchConfiguration('w_rho')
    w_damp_base = LaunchConfiguration('w_damp_base')

    # Nodes
    flipper_attitude_node = Node(
        package='firefighter_flipper',
        executable='flipper_attitude_control',
        name='flipper_attitude_control',
        output='screen',
        parameters=[{
            'Kp_omega': Kp_omega,
            'tau_rho': tau_rho,
            'rho_dot_max_deg': rho_dot_max_deg,
            'w_task': w_task,
            'w_rho': w_rho,
            'w_damp_base': w_damp_base,
        }],
    )

    flipper_vel_to_dir_node = Node(
        package='firefighter_flipper',
        executable='flipper_velocity_to_direction',
        name='flipper_velocity_to_direction',
        output='screen',
        parameters=[{
            'velocity_threshold': velocity_threshold,
        }],
    )

    return LaunchDescription([
        velocity_threshold_arg,
        Kp_omega_arg,
        tau_rho_arg,
        rho_dot_max_deg_arg,
        w_task_arg,
        w_rho_arg,
        w_damp_base_arg,
        flipper_attitude_node,
        flipper_vel_to_dir_node,
    ])


